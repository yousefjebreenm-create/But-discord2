/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║              Hell | UI Design Library                       ║
 * ║  مكتبة التصميم المركزية — غيّر من هنا ويتغير في كل مكان   ║
 * ╚══════════════════════════════════════════════════════════════╝
 */

const COLORS = {
  "accent": 15140870,
  "success": 15140870,
  "error": 15140870,
  "warn": 15140870,
  "info": 15140870
};

const EMOJI = {
  "ticket": "<:Untitled_3:1513737804964827216>",
  "ticketNum": "<:Untitled_5:1513737859667067000>",
  "question": "<:Untitled_7:1513737863534084157>",
  "user": "<:Untitled_2:1513737772861620304>",
  "userId": "<:Untitled_22:1513737778939297802>",
  "dm": "<:Untitled_37:1513737823537336380>",
  "close": "<:Untitled_11:1513737757078327306>",
  "claimed": "<:Untitled_36:1513737821729325057>",
  "attachment": "<:Untitled_18:1513737769837400186>",
  "support": "",
  "create": "<:Untitled6:1497393339157184705>",
  "rules": "<:Untitled_21:1513737777093804234>",
  "info": "<:Untitled_22:1513737778939297802>",
  "comment": "<:Untitled_30:1513737806508200056>",
  "error": "<:Untitled_35:1513737820110454885>",
  "success": "<:Untitled_36:1513737821729325057>"
};

const BUTTON_EMOJI = {
  "create": {
    "id": "1497393339157184705",
    "name": "Untitled6"
  },
  "rules": {
    "id": "1513737777093804234",
    "name": "Untitled_21"
  },
  "info": {
    "id": "1513737778939297802",
    "name": "Untitled_22"
  }
};

const EMOJI_URL = {
  "create": "https://cdn.discordapp.com/emojis/1497393339157184705.webp",
  "rules": "https://cdn.discordapp.com/emojis/1513737777093804234.webp",
  "info": "https://cdn.discordapp.com/emojis/1513737778939297802.webp"
};

const IMAGES = {
  "logo": "https://cdn.discordapp.com/attachments/1445938421032943707/1515625159699070976/pz21sht.png?ex=6a2faf6d&is=6a2e5ded&hm=89b6cb46087d02f68785981b6607f19c2f4a05b03f394c84e50f6cfcf0e922ed&",
  "footerIcon": "",
  "bannerPanel": "https://cdn.discordapp.com/attachments/1445938421032943707/1515624941964492810/2fn9bj1.png?ex=6a2faf39&is=6a2e5db9&hm=4f0519c290f578ed55aa6125755edfa5c5cdd968e10cfae4ae013bd0cce55a98&",
  "bannerClose": ""
};

const BRAND = {
  "footer": "CodeX | Support System",
  "footerSub": "CodeX | Management Team",
  "panelTitle": "CDX | Support"
};

module.exports = { COLORS, EMOJI, BUTTON_EMOJI, EMOJI_URL, IMAGES, BRAND };
